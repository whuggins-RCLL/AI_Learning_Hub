# Current Feature Research Protocol

For product capabilities, access, screenshots, tutorials, and vendor training, search the web at the time of use because features change frequently.

Use sources in this order:
1. Official Stanford or RCLL pages.
2. Official vendor documentation, academy, help center, release notes, or product training.
3. Official product announcements or webinars.
4. Reputable academic or professional sources only when official material is insufficient.

Avoid affiliate blogs, anonymous tutorials, unsupported social posts, promotional comparison sites, and stale screenshots presented as current. State the check date. Distinguish:
- confirmed as available to SLS;
- publicly advertised by the vendor;
- availability to SLS unknown.

Prefer current official tutorials and screenshots. Do not reproduce lengthy copyrighted material. Summarize and link to the source.
