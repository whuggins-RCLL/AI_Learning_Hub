# Stanford and RCLL Student AI Resources

## Start here
- AI Essentials Training (strongly encouraged, not required): https://bit.ly/rcll-aiessentials
- AI in the Library: https://ai-at-rcll.vercel.app/
- AI Learning Hub: https://sites.google.com/law.stanford.edu/ailearninghub/
- The AI Upload: https://sites.google.com/law.stanford.edu/ailearninghub/the-ai-upload
- AI Curiosity Corner: https://sites.google.com/law.stanford.edu/ailearninghub/events
- SLS AI Initiative: https://law.stanford.edu/ai-initiative/

## RCLL-provided AI tools
- Harvey AI: https://www.harvey.ai/
- Harvey Academy: https://academy.harvey.ai/
- Legora: https://legora.com/
- LexText: https://www.lextext.ai/
- CICERO by Rhetoric: https://www.userhetoric.com/
- Request access: http://bit.ly/rcll-legalairequest

Access rules: current SLS community only; access ends after graduation; requests are manually approved; use Stanford SSO with SUNet credentials; AI Essentials is encouraged but not required. For access, technical problems, tool selection, or AI and legal research help, email **library@law.stanford.edu**. Course-permission questions belong with the instructor.

## Legal databases with AI features
- Lexis Protégé: http://lawschool.lexis.com/
- Westlaw Precision: https://lawschool.westlaw.com/
- Bloomberg AI: http://www.bloomberglaw.com/

## Stanford-provided general AI
- Stanford AI Playground: https://uit.stanford.edu/service/aiplayground
- Gemini: https://uit.stanford.edu/service/gsuite/geminiapp
- NotebookLM: https://uit.stanford.edu/service/gsuite/notebooklm
- Microsoft Copilot: https://uit.stanford.edu/service/microsoft365/mscopilotchat

Do not assume every publicly advertised vendor feature is enabled for SLS. Check current official sources and label availability as confirmed, advertised, or unknown.
