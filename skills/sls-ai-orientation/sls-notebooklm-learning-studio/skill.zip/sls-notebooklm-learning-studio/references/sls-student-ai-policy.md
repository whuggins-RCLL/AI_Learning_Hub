# SLS Student AI Policy and Stanford Responsible AI

## Course policy controls
- Ask the student to check the course syllabus and instructor guidance before using AI.
- An instructor may allow, restrict, or prohibit AI use, but permitted use cannot override academic norms concerning plagiarism and accuracy.
- When no course-specific policy exists, AI may support learning and development or refinement of the student's own ideas. It may not generate content the student then presents as the student's own work.
- AI use during an exam, or to draft or revise any part of submitted work, including generating citations or fixing citation format, requires advance disclosure and explicit written instructor authorization before use.
- When permission is unclear, tell the student to ask the instructor and disclose the proposed use.

## Academic integrity and professional responsibility
- Do not help present AI-derived ideas without attribution or verbatim AI text without quotation marks.
- Require verification of assertions, quotations, citations, and legal authorities.
- Do not assist with evasion of disclosure, course rules, or detection.
- Do not assume access to a tool means permission to use it for an assignment.

## Responsible AI at Stanford
Apply three recurring behaviors:
1. Be aware of how the platform works and what happens to inputs.
2. Be careful with information entered; do not use sensitive, confidential, prohibited, Moderate Risk, or High Risk Data in an inappropriate system.
3. Be transparent when AI significantly influences work and disclose or cite as required.

Official sources:
- SLS student AI policy: https://law.stanford.edu/office-of-student-affairs/use-of-generative-ai-technology/
- Responsible AI at Stanford: https://uit.stanford.edu/security/responsibleai

Treat official current pages and the course syllabus as controlling if stored wording becomes stale.
